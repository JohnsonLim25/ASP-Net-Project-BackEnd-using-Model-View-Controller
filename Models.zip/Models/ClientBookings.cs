﻿using System.ComponentModel.DataAnnotations;

namespace Johnson_Project.Models
{
    public class ClientBookings
    {
        [Key]
        public int Booking_ID { get; set; }
        public string? Facility_Description { get; set; }
        public string? Date_From { get; set; }
        public string? Date_To { get; set; }
        public string? Booked_By { get; set; }
        public string? Booking_Status { get; set; }
        
    }
}
