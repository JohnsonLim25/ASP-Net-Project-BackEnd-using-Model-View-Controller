﻿namespace Johnson_Project.Models
{
    public class UserRoles
    {
        public const string Admin = "Admin";
        public const string Member = "Member";
    }
}
