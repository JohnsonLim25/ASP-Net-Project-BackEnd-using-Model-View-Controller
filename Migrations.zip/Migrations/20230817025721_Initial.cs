﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Johnson_Project.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ClientBookings",
                columns: table => new
                {
                    Booking_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Facility_Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Date_From = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Date_To = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Booked_By = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Booking_Status = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClientBookings", x => x.Booking_ID);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ClientBookings");
        }
    }
}
