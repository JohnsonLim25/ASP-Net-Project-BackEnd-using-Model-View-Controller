﻿using Johnson_Project.Data;
using Johnson_Project.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Johnson_Project.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class BookingsController : ControllerBase
    {
        private readonly ApplicationDBContext _context;

        public BookingsController(ApplicationDBContext context)
        {
            _context = context;
        }

        [Authorize(Roles = UserRoles.Member)]
        [HttpGet]
        public IActionResult GetAll() 
        {
            return Ok(_context.ClientBookings);
        }

        [Authorize(Roles = UserRoles.Member)]
        [HttpPost]
        public IActionResult Post(ClientBookings clientBookings)
        {
            _context.ClientBookings.Add(clientBookings);
            _context.SaveChanges();

            return CreatedAtAction("GetAll", new { Booking_ID = clientBookings.Booking_ID }, clientBookings);
        }

        [Authorize(Roles = UserRoles.Member)]
        [HttpPut]
        public IActionResult Put(int Booking_ID, ClientBookings clientBookings) 
        {
            var client = _context.ClientBookings.FirstOrDefault(e => e.Booking_ID == Booking_ID);
            if(client == null)
            {
                return Problem(detail: "Client with id " + Booking_ID + "is not found.", statusCode: 404);
            }

            client.Facility_Description = clientBookings.Facility_Description;
            client.Date_From = clientBookings.Date_From;
            client.Date_To = clientBookings.Date_To;
            client.Booked_By = clientBookings.Booked_By;
            client.Booking_Status = clientBookings.Booking_Status;

            _context.SaveChanges();

            return Ok(client);
        }

        [Authorize(Roles = UserRoles.Member)]
        [HttpDelete]
        public IActionResult Delete(int Booking_ID, ClientBookings clientBookings) 
        {
            var client = _context.ClientBookings.FirstOrDefault(e => e.Booking_ID == Booking_ID);
            if (client == null)
            {
                return Problem(detail: "Client with id " + Booking_ID + "is not found.", statusCode: 404);
            }

            _context.ClientBookings.Remove(client);
            _context.SaveChanges();

            return Ok(client);
        }
    }
}
